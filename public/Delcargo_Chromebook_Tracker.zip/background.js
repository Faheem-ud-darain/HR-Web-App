// Delcargo HR Tracker — Background Service Worker (Manifest V3)
// Automatic active shift detection, idle tracking, heartbeats, screen captures,
// and 37-minute continuous idle auto clock-out on ChromeOS & Chrome browser.

importScripts('capture-health.js'); // buildHeartbeat / afterCapture / CAPTURE_REASONS (globalThis.CaptureHealth)

const DEFAULT_SERVER_URL = 'https://pb.delcargo.us';
const IDLE_DETECTION_SECONDS = 180; // Chrome reports "idle" only after this long without input, so a stretch really began this long before the report
const INACTIVITY_REPORT_SECONDS = 180; // 3 minutes — loggable idle threshold
const AUTO_ABSENT_INACTIVITY_SECONDS = 37 * 60; // 37 minutes — continuous idle auto clock-out

// Initial Alarm Setup (Default: 1 minute screenshot interval)
try {
  chrome.idle.setDetectionInterval(IDLE_DETECTION_SECONDS);
  chrome.alarms.create('tracker_heartbeat', { periodInMinutes: 0.25 }); // every 15 sec
  chrome.alarms.create('tracker_screenshot', { periodInMinutes: 1 });  // 1 min default
} catch (e) {
  console.error('[Delcargo Tracker] Alarm setup error:', e);
}

// Ensure Offscreen Document exists for full desktop MediaStream capture
async function ensureOffscreenDocument() {
  try {
    const existing = await chrome.offscreen.hasDocument();
    if (!existing) {
      await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['DISPLAY_MEDIA', 'USER_MEDIA'],
        justification: 'Capture full desktop screen for HR activity logging'
      });
      console.log('[Delcargo Tracker] Offscreen capture document created.');
    }
  } catch (err) {
    console.error('[Delcargo Tracker] Offscreen document creation error:', err);
  }
}

// ── Top-level Event Listeners (Manifest V3 Requirement) ─────────────────────

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Delcargo Tracker] Extension installed.');
  ensureOffscreenDocument();
  handleHeartbeatTick();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'HEARTBEAT_NOW') {
    console.log('[Delcargo Tracker] Immediate heartbeat requested by UI.');
    handleHeartbeatTick()
      .then(() => sendResponse({ success: true }))
      .catch(() => sendResponse({ success: false }));
    return true;
  }
  if (msg && msg.type === 'INIT_DESKTOP_STREAM') {
    (async () => {
      await ensureOffscreenDocument();
      await new Promise(r => setTimeout(r, 150));
      chrome.runtime.sendMessage({ type: 'START_SCREEN_STREAM', streamId: msg.streamId }, (offscreenRes) => {
        const err = chrome.runtime.lastError;
        if (err) {
          console.error('[Delcargo Tracker] Offscreen message error:', err.message);
          sendResponse({ success: false, error: err.message });
        } else {
          console.log('[Delcargo Tracker] Offscreen stream init response:', offscreenRes);
          sendResponse(offscreenRes || { success: false, error: 'No response from offscreen document' });
        }
      });
    })();
    return true;
  }
  if (msg && msg.type === 'DISCONNECT_DEVICE') {
    getStorageData().then(async (data) => {
      if (data.employeeEmail) {
        const serverUrl = (data.serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
        const email = data.employeeEmail.trim().toLowerCase();
        // Signal 2: Write explicit quit intent before clearing heartbeat
        try {
          await setTrackerSignalField(serverUrl, email, 'quit_intent', {
            employeeEmail: email,
            timestamp: new Date().toISOString()
          });
        } catch {}
        await clearTrackerSignalField(serverUrl, email, 'heartbeat');
      }
      sendResponse({ success: true });
    });
    return true;
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  console.log('[Delcargo Tracker] Alarm fired:', alarm.name);
  if (alarm.name === 'tracker_heartbeat') {
    handleHeartbeatTick();
  } else if (alarm.name === 'tracker_screenshot') {
    handleScreenshotTick();
  }
});

// Storage Helper
async function getStorageData() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      [
        'employeeEmail',
        'serverUrl',
        'deviceId',
        'agentToken',
        'shiftActive',
        'shiftStartTime',
        'idleStartTimestamp',
        'autoAbsentFired',
        'lastScreenshotTime',
        'lastUploadedAt',
        'captureBlocked',
        'lastCaptureError',
        'captureFailures',
        'screenshotIntervalMinutes'
      ],
      (res) => resolve(res || {})
    );
  });
}

// ── hr_tracker_signals helpers (plan 027 Phase 4b) ──────────────────────────
// One row per employee (unique index on "email"), 8 named json sub-fields —
// heartbeat, shift_stop_signal, quit_intent, ping, pong, stop_cmd, command,
// diagnostics — replacing the 8 separate hr_delcargo_store KV keys this
// extension used to read/write directly (tracker_heartbeat_<email>,
// tracker_ping_<email>, tracker_pong_<email>, tracker_stop_cmd_<email>,
// tracker_quit_intent_<email>, shift_stop_signal_<email>). Mirrors
// pbGetTrackerSignal/pbSetTrackerSignal/pbClearTrackerSignal in
// src/lib/hr/shared.ts (web portal) and get_tracker_signal_field/
// set_tracker_signal_field/clear_tracker_signal_field in
// tracker-agent/agent_gui.py (Windows/Mac desktop agent) — same collection,
// same field names, so a payload built here round-trips through hrData.ts
// unchanged. Added when the extension was found to still be talking to the
// now-dead hr_delcargo_store collection after Phase 4b's hard cutover
// (2026-09-13), which silently broke Start Shift / the "App Connected"
// heartbeat badge for every Chromebook — see the ChromeOS tracker
// investigation in Notes/PROJECT_HISTORY.md around 2026-09-14.
const TRACKER_SIGNALS_COLLECTION = 'hr_tracker_signals';

async function getTrackerSignalRecord(serverUrl, email) {
  const cleanUrl = (serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
  const key = (email || '').trim().toLowerCase();
  try {
    const res = await fetch(
      `${cleanUrl}/api/collections/${TRACKER_SIGNALS_COLLECTION}/records?filter=${encodeURIComponent(`email="${key}"`)}&perPage=1`,
      { method: 'GET', headers: { 'Content-Type': 'application/json' } }
    );
    if (!res.ok) return null;
    const data = await res.json();
    return data?.items?.[0] || null;
  } catch {
    return null;
  }
}

async function getTrackerSignalField(serverUrl, email, field) {
  const record = await getTrackerSignalRecord(serverUrl, email);
  if (!record) return null;
  let value = record[field];
  // PocketBase can hand json fields back as strings over plain REST —
  // decode defensively (same caution as agent_gui.py's own helper).
  if (typeof value === 'string') {
    try {
      value = JSON.parse(value);
    } catch {
      return null;
    }
  }
  return value ?? null;
}

async function setTrackerSignalField(serverUrl, email, field, value) {
  const cleanUrl = (serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
  const key = (email || '').trim().toLowerCase();
  const existing = await getTrackerSignalRecord(cleanUrl, key);
  const payload = JSON.stringify({ email: key, [field]: value });
  if (existing?.id) {
    await fetch(`${cleanUrl}/api/collections/${TRACKER_SIGNALS_COLLECTION}/records/${existing.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: payload
    });
  } else {
    await fetch(`${cleanUrl}/api/collections/${TRACKER_SIGNALS_COLLECTION}/records`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload
    });
  }
}

async function clearTrackerSignalField(serverUrl, email, field) {
  // Nulls the field rather than deleting the row — sibling signals may
  // still be live on it (same semantic as the desktop agent/portal).
  await setTrackerSignalField(serverUrl, email, field, null);
}

// ── Real hr_tracking_settings lookup ────────────────────────────────────────
// Fixed 2026-08-25 — this used to read a KV row (hr_tracking_settings_prod_v1)
// from before the web app migrated tracking settings to a real PocketBase
// collection with a unique index on employeeEmail (see hrData.ts's
// getAllTrackingSettings/updateTrackingSettings). The web app stopped writing
// to that KV key entirely once the migration landed, so this lookup always
// returned null: (1) popup.js's setup-code connect flow could never validate
// ANY current/regenerated setup code — every Chromebook trying to connect or
// reconnect got "This setup code is not recognized," full stop; and (2) even
// an already-connected Chromebook fell back to a hardcoded 1-minute
// screenshot interval forever, ignoring whatever HR configured. Same bug
// class as get_tracking_settings in tracker-agent/agent_gui.py, which got
// this exact fix on 2026-08-18 — the extension just never got the same
// treatment. Also NEW here: this is the only place that checks `enabled` at
// all for this extension — previously nothing did (see handleHeartbeatTick),
// so toggling an employee's tracking to "Inactive" in TrackingView had zero
// effect on a connected Chromebook; it kept capturing for as long as a shift
// was open. Returns the settings record (with `enabled`, `intervalMinutes`,
// `employeeEmail`) or null if the token isn't recognized by the server.
//
// Unaffected by the Phase 4b hr_tracker_signals migration below —
// hr_tracking_settings is a separate, unmigrated collection.
async function getTrackingSettingsByToken(serverUrl, agentToken) {
  if (!agentToken) return null;
  try {
    const cleanUrl = (serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
    const res = await fetch(
      `${cleanUrl}/api/collections/hr_tracking_settings/records?filter=${encodeURIComponent(`agentToken="${agentToken}"`)}&perPage=1`,
      { method: 'GET', headers: { 'Content-Type': 'application/json' } }
    );
    if (!res.ok) return null;
    const data = await res.json();
    return data?.items?.[0] || null;
  } catch (e) {
    console.warn('[Delcargo Tracker] getTrackingSettingsByToken failed:', e);
    return null;
  }
}

// ── Automatic Active Shift Checker (Matches desktop agent check_active_shift) ─
async function checkActiveShift(serverUrl, email) {
  const cleanUrl = (serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
  const res = await fetch(`${cleanUrl}/api/collections/hr_timesheets/records?filter=${encodeURIComponent('clock_out = ""')}&perPage=200`, {
    method: 'GET',
    headers: { 'Content-Type': 'application/json' }
  }).catch(() => null);

  if (!res || !res.ok) return null;
  const data = await res.json().catch(() => null);
  const items = data?.items || [];
  const wanted = (email || '').trim().toLowerCase();

  const openRecord = items.find(it => (it.employee_id || '').trim().toLowerCase() === wanted);
  return openRecord || null;
}

// ── Heartbeat & Shift Tick Handler ─────────────────────────────────────────
async function handleHeartbeatTick() {
  const data = await getStorageData();
  if (!data.employeeEmail) return;

  const serverUrl = (data.serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
  const email = data.employeeEmail.trim().toLowerCase();
  const nowIso = new Date().toISOString();
  const deviceId = data.deviceId || ('chromebook_' + email.replace(/[^a-z0-9]/g, '_'));

  // 1. ALWAYS upload live tracker heartbeat while extension is connected (v11)
  try {
    const existingHb = await getTrackerSignalField(serverUrl, email, 'heartbeat');

    // Check if superseded by another device — but only act on it if that
    // other device's heartbeat is actually recent. Without a staleness
    // check here, this extension would immediately disconnect itself the
    // instant it saw ANY competing deviceId, including one that's long
    // dead (e.g. an old Chromebook that was never properly signed out) or
    // a benign write-order race against its own last check-in. 60s matches
    // the equivalent guard in tracker-agent/agent_gui.py's _checkin().
    const HEARTBEAT_SUPERSEDE_STALE_MS = 60 * 1000;
    if (existingHb && existingHb.deviceId && existingHb.deviceId !== deviceId) {
      const lastSeenMs = existingHb.lastSeenAt ? new Date(existingHb.lastSeenAt).getTime() : 0;
      const isOtherDeviceStale = !lastSeenMs || (Date.now() - lastSeenMs > HEARTBEAT_SUPERSEDE_STALE_MS);
      if (!isOtherDeviceStale) {
        console.warn(`[Delcargo Tracker] Superseded by device: ${existingHb.deviceId}. Disconnecting...`);
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: 'Tracker Disconnected',
          message: 'Your profile was logged into another tracker. This extension has been disconnected.'
        });
        chrome.storage.local.clear(() => {
          chrome.runtime.reload();
        });
        return;
      }
      // The other device's heartbeat is stale — it's not actually live.
      // Fall through and claim the slot for this device instead of
      // disconnecting ourselves over a dead record.
    }

    const connectedAt = existingHb?.connectedAt || nowIso;

    // Note: this extension's version numbers (Chrome's required semver-style
    // x.y.z) aren't comparable to the desktop agent's flat incrementing
    // APP_VERSION integer, so needsTrackerUpdate() in trackerSetup.ts
    // deliberately skips the update-required check for this device type —
    // see the deviceLabel check there.
    // Also carries when the last screenshot arrived and why one did not, so the dashboard's "No screenshots
    // for N min" alert works for Chromebooks too (see capture-health.js).
    const hbValue = CaptureHealth.buildHeartbeat({
      email, deviceId, connectedAt, nowIso, version: chrome.runtime.getManifest().version, stored: data
    });

    await setTrackerSignalField(serverUrl, email, 'heartbeat', hbValue);
    console.log(`[Delcargo Tracker] Heartbeat sent for ${email} (${nowIso})`);
  } catch (e) {
    console.error('[Delcargo Tracker] Heartbeat upload failed:', e);
  }

  // 1b. Signal 3 & 4: Ping / Pong Handshake (Respond immediately to portal pings)
  try {
    const pingData = await getTrackerSignalField(serverUrl, email, 'ping');
    if (pingData && pingData.requestId) {
      // Ignore stale pings (> 30 seconds old) to avoid responding to a
      // leftover ping from a previous failed start-shift attempt — mirrors
      // agent_gui.py's _handle_ping staleness guard.
      let isStale = false;
      if (pingData.requestedAt) {
        const ageSeconds = (Date.now() - new Date(pingData.requestedAt).getTime()) / 1000;
        isStale = ageSeconds > 30;
      }
      if (!isStale) {
        console.log('[Delcargo Tracker] Portal ping detected, responding with pong:', pingData.requestId);
        await setTrackerSignalField(serverUrl, email, 'pong', {
          employeeEmail: email,
          requestId: pingData.requestId,
          respondedAt: new Date().toISOString()
        });
      }
      await clearTrackerSignalField(serverUrl, email, 'ping');
    }
  } catch (e) {
    console.warn('[Delcargo Tracker] Ping/pong check error:', e);
  }

  // 1c. Signal 5: Stop Command from web portal
  try {
    const stopCmd = await getTrackerSignalField(serverUrl, email, 'stop_cmd');
    if (stopCmd) {
      console.log('[Delcargo Tracker] Stop command received from portal.');
      await clearTrackerSignalField(serverUrl, email, 'stop_cmd');
      if (data.shiftActive) {
        await autoClockOut(serverUrl, email, 'portal_stop_cmd');
      }
    }
  } catch (e) {
    console.warn('[Delcargo Tracker] Stop cmd check error:', e);
  }

  // 1d. Signal 6 & 7: Remote command channel (HR's "Run Diagnostics" /
  // "Reload Settings Now" buttons in TrackingView.tsx). Added alongside
  // the Phase 4b migration above — this extension previously had no
  // handling for the command/diagnostics fields at all, so those buttons
  // silently did nothing for a Chromebook even before the KV-collection
  // break. Mirrors agent_gui.py's _handle_command.
  try {
    const commandData = await getTrackerSignalField(serverUrl, email, 'command');
    if (commandData && commandData.type) {
      let isStale = false;
      if (commandData.issuedAt) {
        const ageSeconds = (Date.now() - new Date(commandData.issuedAt).getTime()) / 1000;
        isStale = ageSeconds > 60;
      }
      if (!isStale) {
        if (commandData.type === 'diagnostics') {
          console.log('[Delcargo Tracker] Diagnostics command received from portal.');
          await setTrackerSignalField(serverUrl, email, 'diagnostics', {
            employeeEmail: email,
            respondedAt: new Date().toISOString(),
            appVersion: chrome.runtime.getManifest().version,
            platform: 'ChromeOS',
            deviceLabel: 'Chromebook / Chrome OS',
            connected: true,
            connectionStatus: 'connected',
            enabled: !!data.shiftActive,
            enabledByHr: !!data.shiftActive,
            shiftActive: !!data.shiftActive,
            isLocked: false,
            lastError: data.lastCaptureError || null,
            lastCaptureAt: data.lastUploadedAt ? new Date(data.lastUploadedAt).toISOString() : null,
            consecutiveCaptureFailures: data.captureFailures || 0,
            intervalMinutes: data.screenshotIntervalMinutes || 1,
            autostart: true,
            updateAvailableVersion: null
          });
        }
        // 'reload_settings' needs no extra action — this tick already just
        // re-fetched tracking settings fresh (see step 3 below), and the
        // next tick (<=15s away) will too. Just acknowledge by clearing it.
      }
      await clearTrackerSignalField(serverUrl, email, 'command');
    }
  } catch (e) {
    console.warn('[Delcargo Tracker] Command check error:', e);
  }

  // 2. Query real shift status on PocketBase (matches desktop tracker)
  const openShiftRecord = await checkActiveShift(serverUrl, email);
  const isShiftOpen = !!openShiftRecord;
  console.log(`[Delcargo Tracker] Shift active status: ${isShiftOpen}`);

  if (isShiftOpen) {
    const clockInIso = openShiftRecord.clock_in || nowIso;
    chrome.storage.local.set({
      shiftActive: true,
      shiftStartTime: clockInIso,
      // A shift that has just opened must not inherit an idle stretch from before it.
      ...(data.shiftActive ? {} : { idleStartTimestamp: null, autoAbsentFired: false })
    });

    // 3. Fetch this device's real tracking settings (hr_tracking_settings,
    // matched by agentToken) — both the enabled/disabled gate AND the
    // custom screenshot interval now come from here. Previously NOTHING
    // checked `enabled` at all in this extension (only shift-open gated
    // capture), so toggling an employee's tracking to "Inactive" in
    // TrackingView had zero effect on an already-connected Chromebook —
    // it kept capturing regardless. Fixed 2026-08-25.
    const trackingSettings = await getTrackingSettingsByToken(serverUrl, data.agentToken);
    const enabledByHr = !!trackingSettings?.enabled;
    let intervalMinutes = 1;
    if (trackingSettings?.intervalMinutes) {
      intervalMinutes = Math.max(1, parseInt(trackingSettings.intervalMinutes, 10) || 1);
    }
    chrome.storage.local.set({ screenshotIntervalMinutes: intervalMinutes });

    if (!trackingSettings) {
      // Token not recognized by the server at all — e.g. HR regenerated
      // this employee's setup code, or the row was never created. Don't
      // capture anything until this device is reconnected with a current
      // setup code; still fall through to the idle/auto-absence check
      // below since that's about attendance, not screen recording.
      console.warn('[Delcargo Tracker] Setup token not recognized by server — ask HR/Admin to check your setup.');
      // Reported in the heartbeat, so HR sees the real cause instead of a vague "no screenshots".
      chrome.storage.local.set({ captureBlocked: 'token', lastCaptureError: CaptureHealth.CAPTURE_REASONS.staleToken });
    } else if (!enabledByHr) {
      console.log('[Delcargo Tracker] Tracking is disabled for this account — skipping capture.');
      chrome.storage.local.set({ captureBlocked: 'disabled', lastCaptureError: null });
    } else {
      if (data.captureBlocked) chrome.storage.local.set({ captureBlocked: null, lastCaptureError: null });
      // ── Staggered screenshot uploads (see staggered_screenshot_plan.md) ──
      // Without this, lastScreenshotTime starts at 0, so the very first
      // "is it due" check after a shift opens is always true — meaning every
      // Chromebook whose shift starts at (near) the same moment captures its
      // first screenshot in the same instant, and then repeats that same
      // synchronized timing every interval afterward. screenshotJitterMs is a
      // small persistent per-device offset (0–45s, matching the desktop
      // agent's initial_jitter) generated once and reused — NOT regenerated
      // every tick, which would just be noise instead of a stable phase
      // offset — so this device's captures settle into their own consistent,
      // randomized slot instead of everyone's boundary lining up.
      let jitterMs = data.screenshotJitterMs;
      if (typeof jitterMs !== 'number') {
        jitterMs = Math.floor(Math.random() * 45000);
        chrome.storage.local.set({ screenshotJitterMs: jitterMs });
      }

      const lastShot = data.lastScreenshotTime || 0;
      const intervalMs = intervalMinutes * 60 * 1000;
      let isDue;
      if (lastShot === 0) {
        // First capture since this shift opened — stagger from shift start
        // by this device's jitter offset rather than firing instantly.
        const shiftStartMs = new Date(clockInIso).getTime() || Date.now();
        isDue = (Date.now() - shiftStartMs) >= jitterMs;
      } else {
        // Small +/-3s wobble each cycle on top of the base interval so
        // repeated captures don't resettle into lockstep with any other
        // device even when configured intervals match exactly.
        const wobbleMs = Math.random() * 6000 - 3000;
        isDue = (Date.now() - lastShot) >= (intervalMs + wobbleMs);
      }
      if (isDue) {
        chrome.storage.local.set({ lastScreenshotTime: Date.now() });
        console.log('[Delcargo Tracker] Screenshot due -> capturing screen now...');
        handleScreenshotTick();
      }
    }

    // 4. Live continuous 37+ minutes idle check (only during active shift)
    chrome.idle.queryState(IDLE_DETECTION_SECONDS, async (state) => {
      if (state === 'idle' || state === 'locked') {
        const idleStart = idleStretchStart(data.idleStartTimestamp, data.shiftStartTime, Date.now());
        const continuousIdleSec = Math.floor((Date.now() - idleStart) / 1000);

        if (continuousIdleSec >= AUTO_ABSENT_INACTIVITY_SECONDS && !data.autoAbsentFired) {
          chrome.storage.local.set({ autoAbsentFired: true });
          // The stretch goes to the inactivity log first, while the shift is still open: that log is the only record of it, and the web app
          // makes the absence from it. This extension never creates an absence itself.
          await uploadInactivityLog(serverUrl, email, new Date(idleStart).toISOString(), new Date().toISOString(), continuousIdleSec);
          await autoClockOut(serverUrl, email, 'inactivity_absence');
        }
      }
    });

  } else {
    // Shift is not open (shift ended or not started yet) -> pause active shift flag
    if (data.shiftActive) {
      chrome.storage.local.set({ shiftActive: false, autoAbsentFired: false, idleStartTimestamp: null });
    }
  }
}

// When the current idle stretch began, as far as this device can tell: the saved start (kept from the first idle or lock report, so locking
// the screen does not restart the clock), or, if none was saved, the moment Chrome's own detection delay puts it. Never before the shift began.
function idleStretchStart(savedStart, shiftStartIso, now) {
  const start = savedStart || (now - IDLE_DETECTION_SECONDS * 1000);
  const shiftStart = Date.parse(shiftStartIso || '');
  return Number.isFinite(shiftStart) ? Math.max(start, shiftStart) : start;
}

// ── Auto Clock Out / Shift Stop ───────────────────────────────────────────
async function autoClockOut(serverUrl, email, reason = 'tracker_closed') {
  try {
    const cleanUrl = (serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
    console.log(`[Delcargo Tracker] Auto clock-out triggered. Reason: ${reason}`);

    // 1. Clock out open timesheet record
    const openRecord = await checkActiveShift(cleanUrl, email);
    if (openRecord?.id) {
      const nowIso = new Date().toISOString();
      await fetch(`${cleanUrl}/api/collections/hr_timesheets/records/${openRecord.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clock_out: nowIso, status: 'Completed' })
      });
    }

    // 2. Write shift_stop_signal for live web dashboard notification
    await setTrackerSignalField(cleanUrl, email, 'shift_stop_signal', {
      employeeEmail: email,
      timestamp: new Date().toISOString(),
      reason
    });

    // 3. Update local state
    chrome.storage.local.set({ shiftActive: false, autoAbsentFired: false });

    // 4. Native Chrome OS Notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Delcargo Shift Ended',
      message: reason === 'inactivity_absence'
        ? 'Your shift was automatically ended due to 37+ minutes of inactivity.'
        : 'Your shift has ended.'
    });
  } catch (err) {
    console.error('[Delcargo Tracker] autoClockOut failed:', err);
  }
}

// ── Idle State Changed Listener ───────────────────────────────────────────
chrome.idle.onStateChanged.addListener(async (newState) => {
  const data = await getStorageData();
  if (!data.shiftActive || !data.employeeEmail) {
    if (data.idleStartTimestamp) chrome.storage.local.set({ idleStartTimestamp: null }); // no shift: nothing to count, and nothing to carry into the next one
    return;
  }

  const serverUrl = (data.serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
  const email = data.employeeEmail.trim().toLowerCase();
  const now = Date.now();

  if (newState === 'idle' || newState === 'locked') {
    // Keep the FIRST start: an idle stretch that ends in a screen lock is one stretch, not two. Chrome says "idle" only after its detection
    // delay, so the stretch began that long ago; a lock with no earlier idle began now.
    if (!data.idleStartTimestamp) chrome.storage.local.set({ idleStartTimestamp: newState === 'idle' ? now - IDLE_DETECTION_SECONDS * 1000 : now });
  } else if (newState === 'active') {
    const idleStart = data.idleStartTimestamp ? idleStretchStart(data.idleStartTimestamp, data.shiftStartTime, now) : null;
    chrome.storage.local.set({ idleStartTimestamp: null, autoAbsentFired: false });

    if (idleStart) {
      const durationSeconds = Math.floor((now - idleStart) / 1000);
      if (durationSeconds >= INACTIVITY_REPORT_SECONDS) {
        await uploadInactivityLog(serverUrl, email, new Date(idleStart).toISOString(), new Date(now).toISOString(), durationSeconds);
      }
    }
  }
});

// Upload completed inactivity interval to hr_inactivity_logs
async function uploadInactivityLog(serverUrl, email, startIso, endIso, durationSeconds) {
  try {
    const cleanUrl = (serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
    await fetch(`${cleanUrl}/api/collections/hr_inactivity_logs/records`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        employee_email: email,
        start_at: startIso,
        end_at: endIso,
        duration_seconds: String(durationSeconds),
        device_label: 'Chromebook / Chrome OS'
      })
    });
    console.log(`[Delcargo Tracker] Logged ${Math.round(durationSeconds / 60)} min inactivity.`);
  } catch (err) {
    console.error('[Delcargo Tracker] Failed to upload inactivity log:', err);
  }
}

// Helper to convert Data URL to Blob for multipart upload
function dataUrlToBlob(dataUrl) {
  const arr = dataUrl.split(',');
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
}

// ── Screen Capture Tick (Full Desktop Monitor via Offscreen / VisibleTab) ───
async function handleScreenshotTick() {
  const data = await getStorageData();
  if (!data.shiftActive || !data.employeeEmail) return;

  const serverUrl = (data.serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, '');
  const email = data.employeeEmail.trim().toLowerCase();

  try {
    // 1. Query full desktop frame from active stream (capture page / offscreen)
    chrome.runtime.sendMessage({ type: 'CAPTURE_DESKTOP_FRAME' }, async (frameRes) => {
      let dataUrl = null;
      let width = '1920';
      let height = '1080';

      if (frameRes && frameRes.success && frameRes.dataUrl) {
        dataUrl = frameRes.dataUrl;
        width = String(frameRes.width || 1920);
        height = String(frameRes.height || 1080);
        console.log(`[Delcargo Tracker] Capturing FULL DESKTOP MONITOR display (${width}x${height})...`);
      } else {
        // 2. Fallback to visible tab capture if full desktop stream tab is not open
        dataUrl = await new Promise((resolve) => {
          chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
            const activeTab = tabs?.[0];
            const windowId = activeTab?.windowId || null;
            if (activeTab) {
              width = String(activeTab.width || 1920);
              height = String(activeTab.height || 1080);
            }
            chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 65 }, (url) => {
              if (chrome.runtime.lastError) resolve(null);
              else resolve(url);
            });
          });
        });
      }

      if (!dataUrl) {
        chrome.storage.local.set(CaptureHealth.afterCapture(data, { ok: false, reason: CaptureHealth.CAPTURE_REASONS.noFrame }, Date.now()));
        return;
      }

      const blob = dataUrlToBlob(dataUrl);
      const filename = `scr_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.jpg`;

      const formData = new FormData();
      formData.append('employee_email', email);
      formData.append('captured_at', new Date().toISOString());
      formData.append('width', width);
      formData.append('height', height);
      formData.append('device_label', frameRes?.success ? 'Chromebook / Chrome OS (Full Desktop Screen)' : 'Chromebook / Chrome OS');
      formData.append('image', blob, filename);

      const resp = await fetch(`${serverUrl}/api/collections/hr_screenshots/records`, {
        method: 'POST',
        body: formData
      }).catch(() => null);

      const reasons = CaptureHealth.CAPTURE_REASONS;
      const outcome = resp && resp.ok ? { ok: true } : { ok: false, reason: resp ? reasons.uploadRejected(resp.status) : reasons.noConnection };
      chrome.storage.local.set(CaptureHealth.afterCapture(data, outcome, Date.now()));
      if (outcome.ok) console.log('[Delcargo Tracker] Full Desktop Screenshot captured & uploaded successfully.');
    });
  } catch (e) {
    console.warn('[Delcargo Tracker] Screenshot tick exception:', e);
  }
}

// ── Automatic Extension Update Check & Listener ────────────────────────────
chrome.runtime.onUpdateAvailable.addListener((details) => {
  console.log('[Delcargo Tracker] Extension update available:', details.version);
  chrome.runtime.reload();
});

function checkForUpdates() {
  if (chrome.runtime.requestUpdateCheck) {
    chrome.runtime.requestUpdateCheck((status) => {
      console.log('[Delcargo Tracker] Update check status:', status);
      if (status === 'update_available') {
        chrome.runtime.reload();
      }
    });
  }
}

try {
  chrome.alarms.create('checkUpdatesAlarm', { periodInMinutes: 60 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'checkUpdatesAlarm') {
      checkForUpdates();
    }
  });
} catch (e) {
  console.warn('[Delcargo Tracker] Alarms setup exception:', e);
}

// ── Start Heartbeat Loop Immediately on Worker Evaluation ─────────────────
// Previously this ALSO ran a raw setInterval(handleHeartbeatTick, 10000) on
// top of the 'tracker_heartbeat' alarm (every 15s) above — two independent
// schedulers both calling the same get-then-write function meant every
// heartbeat/ping/stop-cmd check was being done roughly twice as often as
// intended, doubling PocketBase load for every connected Chromebook and
// creating a real (if rare) race where both ticks could see "no existing
// KV record" at once and each create a duplicate row. chrome.alarms alone
// is the correct MV3 pattern here — unlike setInterval, it survives the
// service worker being suspended and restarted, so nothing is lost by
// dropping the redundant interval. (Note: Chrome enforces a 1-minute floor
// on alarm periods for a *packed*/published extension — the 15s period
// above only fires that fast while loaded unpacked/in developer mode. If
// this is published to a small number of managed Chromebooks unpacked,
// no change needed; if it's ever pushed through the Chrome Web Store,
// re-verify the actual fired interval and adjust SETTINGS_POLL_SECONDS-
// equivalent expectations on the portal side accordingly.)
handleHeartbeatTick();
